<div class="box banners">
    <div class="box-header">
        <div class="box-header-text">Patrocinios</div>
        <div class="box-header-buttons">

        </div>
    </div>
    <div class="box-body">
        <a href=""><img src="<?= $base; ?>/media/sponsors/sponsor1.png" /></a>
        <a href=""><img src="<?= $base; ?>/media/sponsors/sponsor2.png" /></a>
        <a href=""><img src="<?= $base; ?>/media/sponsors/sponsor3.png" /></a>
    </div>
</div>
<div class="box">
    <div class="box-body m-10">
        Criado com ❤️ por <a href="https://carlosdev.com.br" target="_blank">Carlos Dev</a>
    </div>
</div>